import { Hono } from "@hono/hono";
const app = new Hono()

app.get('/courses', (c) => {
  return c.json({
    "courses" : [
      {"id": 1, "name": "Web Software Development"},
      {"id": 2, "name": "Device-Agnostic Design"}
    ]
  })
})

app.get("/courses/:id", (c) => {
  const id = c.req.param("id")
  const courseId = parseInt(id)
  return c.json({
    "course" : {"id": courseId, "name": "Course Name"}  // Fixed: "Course Name" not "Course name"
  })
})

app.post("/courses", async(c) => {  // Changed from GET to POST
  const body = await c.req.json()
  return c.json ({
    "course": {"id": 3, "name": body.name}
  })
})

app.get("/courses/:id/topics", (c) => {
  const id = c.req.param('id')
  return c.json({
    "topics": [
      {"id":1, "name": "Topic 1"},
      {"id":2, "name": "Topic 2"}
    ]
  })
})

app.get('/courses/:cId/topics/:tId/posts', (c) => {
  const courseId = c.req.param('cId')
  const topicId = c.req.param('tId')
  return c.json({
    "posts": [
      {"id": 1, "title": "Post 1"},
      {"id": 2, "title": "Post 2"}
    ]
  })
})

app.get('/courses/:cId/topics/:tId/posts/:pId', (c) => {
  const courseId = c.req.param('cId')
  const topicId = c.req.param('tId')
  const postId = parseInt(c.req.param('pId'))
  return c.json({
    "post": {
      "id": postId,
      "title": "Post Title"
    },
    "answers": [
      {"id": 1, "content": "Answer 1"},
      {"id": 2, "content": "Answer 2"}
    ]
  })
})

export default app;